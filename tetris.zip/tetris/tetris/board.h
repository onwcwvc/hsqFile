#ifndef __BOARD_H_
#define __BOARD_H_
#define BOARD_H 16
#define BOARD_W 10
#define BLOCKSIZE 30

#include"shape.h"
#include <SDL.h>
#include <stdbool.h>

typedef struct{
	SDL_Color color;
	bool std;
}Block;


typedef struct{
	Block matrix[BOARD_H][BOARD_W];
	int score;
	int level;
	int clearlines;
}Gameboard;

void board_init();
void board_draw();
bool board_check_crash(int newx, int newy, Shape* shape);
void board_place_shape();
void board_clear_fulllines();
int board_getlevel();
void board_clearlines();


#endif

