#include "shape.h"
#include "draw.h"
#include "board.h"
#include "control.h"

Shape cur_shape, next_shape;
int delay_cnt;
int status;
int cnt;

static uint8_t tetromino_queue[7];
static uint8_t tetromino_queue_size = 7;
static uint8_t current_index = 0;



const Shape ALL_SHAPE[7] = 
{
	{{{0, 1, 0, 0}, {1, 1, 1, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}}, 3, 0, 3, {160, 160, 160, 255}},//T
	{{{0, 0, 0, 0}, {1, 1, 1, 1}, {0, 0, 0, 0}, {0, 0, 0, 0}}, 3, 0, 4, {160, 160, 100, 255}},//I
	{{{0, 0, 0, 0}, {1, 0, 0, 0}, {1, 1, 1, 0} ,{0, 0, 0, 0}}, 3, 0, 3, {100, 160, 16, 255}}, //J
	{{{0, 0, 0, 0}, {0, 0, 1, 0}, {1, 1, 1, 0}, {0, 0, 0, 0}}, 3, 0, 3, {160, 10, 160, 255}}, //L
	{{{1, 1, 0, 0}, {1, 1, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}}, 3, 0, 2, {16, 160, 160, 255}},//O
	{{{0, 0, 0, 0}, {0, 1, 1, 0}, {1, 1, 0, 0}, {0, 0, 0, 0}}, 3, 0, 3, {255, 128, 255, 255}}, //S
	{{{0, 0, 0, 0}, {1, 1, 0, 0}, {0, 1, 1, 0}, {0, 0, 0, 0}}, 3, 0, 3, {10, 160, 160, 255}},//Z
};

void shape_rotate()
{
	int size = cur_shape.size;
	Shape nx_shape = cur_shape; 
	char matrix[size][size];
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
			matrix[i][j] = cur_shape.matrix[i][j];
	}
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
			nx_shape.matrix[i][j] = matrix[size-1-j][i];
	}
	if (!board_check_crash(nx_shape.x, nx_shape.y, &nx_shape))
	{
		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
				cur_shape.matrix[i][j] = matrix[size-1-j][i];
		}
	}
}

void shape_init()
{
	
	status = rand() % 7;
	next_shape = ALL_SHAPE[rand()%7];
	cur_shape = ALL_SHAPE[status];
	
}

void shape_draw_matrix(int x, int y, Shape* shape)
{
	SDL_Rect r = {0, 0, 30, 30};
	for (int i = 0; i < shape->size; i++)
		for (int j = 0; j < shape->size; j++)
		{
			if (shape->matrix[i][j])
			{
				r.x = (x + shape->x + j) * 30;
				r.y = (y + shape->y + i) * 30;
				draw_rect(&r, &shape->color);
			}
		}
}

void shape_draw()
{
	shape_draw_matrix(0, 0, &cur_shape);
	shape_draw_matrix(9, 1, &next_shape);
	if (control_getstate() == STATE_RUNNING)
	{
		if (delay_cnt++ > 30 - 3*board_getlevel())
		{
			delay_cnt = 0;
			shape_move(MOVE_DOWN);
		}
	}		
	
}



int shape_move(Movedir dir)
{
	switch (dir)
	{
		case MOVE_DOWN:
			if (!board_check_crash(cur_shape.x, cur_shape.y+1, &cur_shape))
			{
				cur_shape.y ++;
				return 1;
			}	
			else
			{
				board_place_shape(&cur_shape);
				board_clear_fulllines();
//				board_clearlines();
				cur_shape = next_shape;
				next_shape = ALL_SHAPE[rand()%7];
				if (board_check_crash(cur_shape.x, cur_shape.y, &cur_shape))
				{
					control_setstate(STATE_GAME_OVER);
				}
				return 0;
			}	
			break;
		case MOVE_LEFT:
			if (!board_check_crash(cur_shape.x-1, cur_shape.y, &cur_shape))
			{
				cur_shape.x --;
				return 1;
			}
			break;
		case MOVE_RIGHT:
			if (!board_check_crash(cur_shape.x+1, cur_shape.y, &cur_shape))
			{
				cur_shape.x ++;
				return 1;
			}	
			break;
		case MOVE_UP:
			shape_rotate();
			break;
	}
	return 0;
}



bool LRis_crash(int direction)
{
	int X = cur_shape.x;
	X += direction; 
	for (int i = 0; i < cur_shape.size; i++)
		for (int j = 0; j < cur_shape.size; j++)
		{
			if (cur_shape.matrix[i][j] && (X + j < 0 || X + j > 9)) 
				return false;
		}
		
	return true;
}

bool DOWN_Crash()
{
	for (int i = 0; i < cur_shape.size; i++)
		for (int j = 0; j < cur_shape.size; j++)
		{
			if (cur_shape.matrix[i][j] && cur_shape.y + j >15) 
			{
				return false;
			}
		}	
	return true;
}
