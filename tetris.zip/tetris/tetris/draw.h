#ifndef DRAW_H
#define DRAW_H

#include <stdio.h>
#include <stdlib.h>
#include <SDL.h>
#include <stdbool.h>
//-limm32
//-lSDL2_ttf

#include <SDL_syswm.h>
#include <windows.h>
#include <imm.h>
#include <SDL_ttf.h>


typedef struct{
	SDL_Window* window;
	SDL_Renderer* renderer;
	TTF_Font* font_big;
	TTF_Font* font_small;
	SDL_Texture* background;
}Renderer;

bool draw_init();
void draw_free();
void draw_rect(const SDL_Rect* rect, const SDL_Color* color);
void draw_updata();
void draw_grid(int a, int b, int dist, SDL_Color* color);
void disableIME(SDL_Window* window);
void draw_string(int x, int y, const char *str, SDL_Color *color, int s);

#endif

