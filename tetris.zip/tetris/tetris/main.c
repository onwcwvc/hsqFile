#include "draw.h"
#include "shape.h"
#include "board.h"
#include "control.h"
#include "interface.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
Mix_Music* music;

int main(int argc, char* argv[]) 
{
	while(1)
	{
		printAnimation();
		if(kbhit())
		{
			char c = getch();
			if (c == 27)
				return 0;
        	else
        		break;
        	
    	}
	}
	make_music();
	SDL_Window* window;
	draw_init();
	shape_init();
	board_init();
//�¼�ѭ��
	control_gameloop();
	draw_free();
	music_free();
	return 0;
}
