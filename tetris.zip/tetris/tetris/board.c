#include "board.h"
#include "shape.h"
#include "draw.h"
#include "control.h"

static Gameboard gb;

int board_getlevel()
{
	return gb.level;
}

void board_init()
{
	gb.score = 0;
	gb.level = 1;
	gb.clearlines = 0;
	for (int i = 0; i < BOARD_H; i++)
	{
		for (int j = 0; j < BOARD_W; j++)
		{
			gb.matrix[i][j] = (Block){{160, 160, 160, 255}, false};
		}
	}
}

void board_draw()
{
	SDL_Rect rect = {0, 0, BLOCKSIZE, BLOCKSIZE};
	for (int i = 0; i < BOARD_H; i++)
	{
		for (int j = 0; j < BOARD_W; j++)
		{
			if (gb.matrix[i][j].std)
			{
				draw_rect(&rect, &gb.matrix[i][j].color);
			}
			rect.x += rect.w;
		}
		rect.x = 0;
		rect.y += rect.h;
	}
	
	char tempstring[32];
    SDL_Color color = {250, 0, 0, 255};
    snprintf(tempstring, sizeof(tempstring), "Score:%3d", gb.score);
    draw_string((BOARD_W+2)*BLOCKSIZE, 7*BLOCKSIZE, tempstring, &color, 30);
    
    color = (SDL_Color){250,255,0,255};
    snprintf(tempstring,sizeof(tempstring),"Level:%3d ", gb.level);
    draw_string((BOARD_W+2)*BLOCKSIZE, 8*BLOCKSIZE, tempstring, &color,30);
    color = (SDL_Color){250,200,0,255};
    snprintf(tempstring,sizeof(tempstring),"Clearlines:%3d ", gb.clearlines);
    draw_string((BOARD_W+2)*BLOCKSIZE, 9*BLOCKSIZE, tempstring, &color,30);

    color = (SDL_Color){250,200,100,255};
    snprintf(tempstring, sizeof(tempstring), "Pause game press P");
    draw_string((BOARD_W+2)*BLOCKSIZE, 11*BLOCKSIZE, tempstring, &color, 12);
    snprintf(tempstring, sizeof(tempstring), "Switch mode press M");
    draw_string((BOARD_W+2)*BLOCKSIZE, 12*BLOCKSIZE, tempstring, &color, 12);
    snprintf(tempstring, sizeof(tempstring), "FallDown press M");
    draw_string((BOARD_W+2)*BLOCKSIZE, 13*BLOCKSIZE, tempstring, &color, 12);
    snprintf(tempstring, sizeof(tempstring), "Game again press R");
    draw_string((BOARD_W+2)*BLOCKSIZE, 14*BLOCKSIZE, tempstring, &color, 12);
    if (control_getstate() == STATE_GAME_OVER)
    {
    	color = (SDL_Color){250, 0, 0, 255};
    	snprintf(tempstring, sizeof(tempstring), "GameOver");
    	draw_string((BOARD_W-7)*BLOCKSIZE, 6*BLOCKSIZE, tempstring, &color, 30);
	}
}

bool board_check_crash(int newx, int newy, Shape* shape)
{
	for (int i = 0; i < shape->size; i++)
		for (int j = 0; j < shape->size; j++)
		{
			
			if (shape->matrix[i][j])
			{
				int x = newx + j;
				int y = newy + i;
				if (x < 0 || x >= BOARD_W || y >= BOARD_H)
					return true;
				if (y > 0 && gb.matrix[y][x].std)
					return true;
			}
		}
		
	return false;
}

void board_place_shape(Shape* shape)
{
	for (int i = 0; i < shape->size; i++)
		for (int j = 0; j < shape->size; j++)
		{
			if (shape->matrix[i][j])
			{
				gb.matrix[shape->y + i][shape->x + j].std = true;
				gb.matrix[shape->y + i][shape->x + j].color = shape->color;
			}
		} 
}

void board_clear_fulllines()
{
	int lines = 0;
	for (int i = 0; i < BOARD_H; i++)
	{
		int flag = 1;
		for (int j = 0; j < BOARD_W; j++)
		{
			if (!gb.matrix[i][j].std)
			{
				flag = 0;
				break;
			}
		}
		if (flag)
		{
			lines++;
			for (int j = i; j > 0; j--)
			{
				for (int k = 0; k < BOARD_W; k++)
				{
					gb.matrix[j][k] = gb.matrix[j-1][k];
				}
			}
			for (int j = 0; j < BOARD_W; j++)
				gb.matrix[0][j].std = false;
		}
	}
	switch(lines)
	{
		case 1: gb.score+=100;
				break;
		case 2: gb.score+=300;
				break;
		case 3: gb.score+=500;
				break;
		case 4: gb.score+=800;
				break;
	}
	gb.clearlines += lines;
	if ((gb.clearlines+1) % 11 == 0)
	{
		gb.level ++;
	}
//	printf("level:%d\nscore:%d\nclear:%d\n", gb.level, gb.score, gb.clearlines);

}

void board_clearlines()
{
	int lines = 0;
	for (int i = BOARD_H - 1; i >= 0; i--)
	{
		int flag = 1;
		for (int j = 0; j < BOARD_W; j++)
		{
			if (!gb.matrix[i][j].std)
				flag = 0;
		}
		if (flag)
		{
			lines++;
			for (int k = i; k >= 0; k--)
			{
				for (int j = 0; j < BOARD_W; j++)
				{
					gb.matrix[k][j] = gb.matrix[k-1][j];
				}
			}
			i++;
			for (int j = 0; j < BOARD_W; j++)
				gb.matrix[0][j].std = false;
		}
	}
	switch(lines)
	{
		case 1: gb.score+=100;
				break;
		case 2: gb.score+=300;
				break;
		case 3: gb.score+=500;
				break;
		case 4: gb.score+=900;
				break;
	}
	gb.clearlines += lines;
	if ((gb.clearlines+1)%11 == 0)
	{
		gb.level ++;
	}
	printf("level:%d\nscore:%d\nclear:%d\n", gb.level, gb.score, gb.clearlines);
}




