#include "draw.h"
#include "shape.h"
#include "board.h"
static Renderer renderer;

void disableIME(SDL_Window* window)
{
	SDL_SysWMinfo wmInfo;
	SDL_VERSION(&wmInfo.version);
	if (SDL_GetWindowWMInfo(window, &wmInfo))
	{
		HWND hwnd = wmInfo.info.win.window;
		// ����IME
		ImmAssociateContext(hwnd, NULL); 
	}
}


bool draw_init()
{
	// ��ʼ�� SDL
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		SDL_Log("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
		return false;
 	}
	// �������� 
	renderer.window = SDL_CreateWindow("SDL2 Square",SDL_WINDOWPOS_CENTERED, 
	SDL_WINDOWPOS_CENTERED, 800, 600, SDL_WINDOW_SHOWN);
	
	if (!renderer.window)
	{
		SDL_Log("Window could not be created! SDL_Error: %s\n", 
		SDL_GetError());
		SDL_Quit();
		return false;
 	}	
	// ������Ⱦ��
	renderer.renderer = SDL_CreateRenderer(renderer.window, -1, SDL_RENDERER_ACCELERATED);
	if (!renderer.renderer)
	{
		SDL_Log("Renderer could not be created! SDL_Error: %s\n", SDL_GetError());
		SDL_DestroyWindow(renderer.window);
		SDL_Quit();
		return false;
 	}
 	disableIME(renderer.window);//ALGER.TTF
 	
 	if (TTF_Init() < 0)
	{
        printf("Failed to initialize SDL_ttf\n");
        draw_free();
        return false;
    }
    renderer.font_big = TTF_OpenFont("javatext.ttf",30);
    if (!renderer.font_big)
	{
        printf("Failed to load font: %s\n",TTF_GetError());
        TTF_Quit();
        draw_free();
        return false;
    }
    renderer.font_small = TTF_OpenFont("javatext.ttf",20);
    if(!renderer.font_small)
	{
        printf("Failed to load font: %s\n",TTF_GetError());
        TTF_Quit();
        draw_free();
        return false;
    }
    
    SDL_Surface* bgSurface = SDL_LoadBMP("true.bmp");
    if (!bgSurface)
    {
    	printf("Failed to load background imag: %s\n", SDL_GetError());
    	exit(1);
	}
	
	renderer.background = SDL_CreateTextureFromSurface(renderer.renderer, bgSurface);
	SDL_FreeSurface(bgSurface);
	if (!renderer.background)
	{
		printf("Failed to create background texture: %s\n", SDL_GetError());
		exit(1);
	}
  
    
// 	printf("draw init success!\n");
 	return true;
}

void draw_free()
{
	// ������Դ
	if (renderer.font_big)
	{
        TTF_CloseFont(renderer.font_big);
        TTF_CloseFont(renderer.font_small);
        TTF_Quit();
    }
	SDL_DestroyRenderer(renderer.renderer);
	SDL_DestroyWindow(renderer.window);
	SDL_Quit();
}

void draw_string(int x, int y, const char *str, SDL_Color *color, int s)
{
    SDL_Surface* surface = TTF_RenderUTF8_Solid(s==30?renderer.font_big:renderer.font_small, str,*color);
    if (!surface)
	{
        printf("TTF_RenderText_Solid error: %s\n",TTF_GetError());
        return;
    }
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer.renderer,surface);
    if (!texture)
	{
        printf("SDL_CreateTextureFromSurFace error:%s\n",SDL_GetError());
        return;
    }

    SDL_Rect rect = {x, y, surface->w, surface->h};
    SDL_FreeSurface(surface);
    SDL_RenderCopy(renderer.renderer,texture,NULL,&rect);   
    SDL_DestroyTexture(texture);
}

void draw_rect(const SDL_Rect* rect, const SDL_Color* color)
{
	SDL_Rect r = *rect;
	SDL_SetRenderDrawColor(renderer.renderer, color->r, color->g, color->b, color->a);
	SDL_RenderFillRect(renderer.renderer, rect);
//	SDL_SetRenderDrawColor(renderer.renderer, 255, 255, 255, 255); //���� 
	SDL_SetRenderDrawColor(renderer.renderer, 0, 255, 0, 255); //����
//	r.x ++, r.y ++, r.w -= 2, r.h -= 2;
//	SDL_RenderDrawRect(renderer.renderer, &r);
}

SDL_Rect rect = {10, 10, 50, 100};
SDL_Color color = {255, 0, 0, 255};

void draw_updata()
{
	// ������Ⱦ����ɫ����ɫ�� 
	SDL_SetRenderDrawColor(renderer.renderer, 20, 200, 200, 0);
//	SDL_SetRenderDrawColor(renderer.renderer, 255, 0, 0, 255); // ��ɫ 
	//	�����Ⱦ�� 
	SDL_RenderClear(renderer.renderer);
	
	SDL_RenderCopy(renderer.renderer, renderer.background, NULL, NULL);
//	draw_rect(&rect, &color);
	//������
	SDL_Color color1 = {250, 255, 250, 255};
	draw_grid(10, 16, 30, &color1); 
	board_draw();
	// ��shape
	shape_draw();
	//  ���� 
//	SDL_SetRenderDrawColor(renderer.renderer, 250, 250, 250, 255);
	SDL_RenderDrawLine(renderer.renderer, 520, 0, 520, 120);
	SDL_RenderDrawLine(renderer.renderer, 300, 120, 520, 120); 
	// ������Ļ��ʾ 
	SDL_RenderPresent(renderer.renderer);
}

void draw_grid(int a, int b, int dist, SDL_Color* color)
{
	SDL_SetRenderDrawColor(renderer.renderer, color->r, color->g, color->b, color->a);
	// ���� 
	for (int i = 0; i <= b; i++)
	{
		SDL_RenderDrawLine(renderer.renderer, 0 , 0 + i * dist, 0 + a * dist, 0 + i * dist);
	}
	for (int i = 0; i <= a; i++)
	{
		SDL_RenderDrawLine(renderer.renderer, 0 + i * dist, 0, 0 + i * dist, 0 + b * dist);
	}
}


