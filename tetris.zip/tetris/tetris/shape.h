#ifndef SHAPE_H
#define SHAPE_H

#include <SDL.h>
#include <stdio.h>
#include <stdbool.h>


typedef enum{
	MOVE_DOWN, MOVE_LEFT, MOVE_RIGHT, MOVE_UP
}Movedir;

typedef struct{
	bool matrix[4][4];
	int x;
	int y;
	int size;
	SDL_Color color;
}Shape;


void shape_init();
void shape_draw();
int shape_move(Movedir dir);
void shape_rotate();
void shape_draw_next();
void make_music();

#endif




 
