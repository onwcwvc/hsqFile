#ifndef INTERFACE_H
#define INTERFACE_H

#include <windows.h>
#include <conio.h>
#include <stdio.h>
#include <SDL.h>
#include <mmsystem.h>
#include <SDL_mixer.h>
#include <stdbool.h>


void setColor(int color);
void setPos(int x,int y);
void printTetris(int x,int y);
void printStart(int x,int y);
void printAnimation();
void music_free();



#endif 
